// inject-env.js — mantido por compatibilidade, valores já estão em pp-config.js
console.log('[inject-env] pp-config.js já contém os valores de produção. Nenhuma injeção necessária.');
